package net.splakra.permitsanddiplomas.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraftforge.network.NetworkEvent;
import net.splakra.permitsanddiplomas.storage.PermitEntry;
import net.splakra.permitsanddiplomas.storage.WorldDataManager;
import net.splakra.permitsanddiplomas.ui.PermitInfoMenu;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class OpenPermitInfoScreenPacket {

    private List<PermitEntry> entries = new ArrayList<>();
    public OpenPermitInfoScreenPacket(List<PermitEntry> entries) {
        this.entries = entries;
    }

    public static void encode(OpenPermitInfoScreenPacket msg, FriendlyByteBuf buf) {
        // Nothing to encode
        buf.writeInt(msg.entries.size());
        for (PermitEntry entry : msg.entries) {
            buf.writeUtf(entry.getTitle());
            buf.writeUtf(entry.getPlayerName());
            buf.writeBoolean(entry.getAccomplished());
            buf.writeUtf(entry.getItemsAsString());
        }
    }

    public static OpenPermitInfoScreenPacket decode(FriendlyByteBuf buf) {
        List<PermitEntry> entries = new ArrayList<>();
        int size = buf.readInt();
        for (int i = 0; i < size; i++) {
            String title = buf.readUtf();
            String playerName = buf.readUtf();
            boolean accomplished = buf.readBoolean();
            String itemsString = buf.readUtf();
            entries.add(new PermitEntry(title, playerName, itemsString, accomplished));
        }

        return new OpenPermitInfoScreenPacket(entries);
    }

    public static void handle(OpenPermitInfoScreenPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                player.openMenu(new SimpleMenuProvider(
                        (id, inventory, playerEntity) -> new PermitInfoMenu(id, inventory, msg.entries),
                        Component.literal("Permit Info")
                ));
            }
        });
        ctx.get().setPacketHandled(true);
    }
}