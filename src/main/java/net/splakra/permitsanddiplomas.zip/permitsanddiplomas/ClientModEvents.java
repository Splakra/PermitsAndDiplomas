package net.splakra.permitsanddiplomas;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.splakra.permitsanddiplomas.ui.ModMenus;
import net.splakra.permitsanddiplomas.ui.PermitInfoMenu;
import net.splakra.permitsanddiplomas.ui.PermitInfoScreen;

public class ClientModEvents {
    /**
     * Fired after vanilla InventoryScreen.init(...). We use
     * ScreenEvent.Init.Post and event.addWidget(...) in 1.20.1.
     */
    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (event.getScreen() instanceof InventoryScreen inv) {
            int x = inv.getGuiLeft();
            int y = inv.getGuiTop();

            Button infoBtn = Button.builder(Component.literal("Info"), btn -> {
                        // open your custom info screen
                        Minecraft.getInstance().setScreen(new PermitInfoScreen(
                                new PermitInfoMenu(ModMenus.PERMIT_INFO_MENU.get(), 0),
                                Minecraft.getInstance().player.getInventory(),
                                Component.literal("Permit Info")
                        ));
                    })
                    .bounds(x + 152, y + 6, 20, 20)
                    .build();

            event.addListener(infoBtn);
        }
    }
}