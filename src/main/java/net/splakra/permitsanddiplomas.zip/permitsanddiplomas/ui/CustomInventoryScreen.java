package net.splakra.permitsanddiplomas.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class CustomInventoryScreen extends InventoryScreen {
    public CustomInventoryScreen(Inventory playerInventory) {
        super(playerInventory.player);
    }

    @Override
    protected void init() {
        super.init();
        // ─── FIX #4: addRenderableWidget exists on InventoryScreen
        this.addRenderableWidget(
                Button.builder(Component.literal("Info"), button -> {
                            Minecraft.getInstance().setScreen(new PermitInfoScreen(
                                    new PermitInfoMenu(ModMenus.PERMIT_INFO_MENU.get(), /*id=*/0),
                                    Minecraft.getInstance().player.getInventory(),
                                    Component.literal("Permit Info")
                            ));
                        })
                        .bounds(this.leftPos + 152, this.topPos + 6, 20, 20)
                        .build()
        );
    }
}
